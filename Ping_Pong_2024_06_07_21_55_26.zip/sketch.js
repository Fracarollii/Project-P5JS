//Ball
let Xball = 300;
let Yball = 200;
let ballDia = 25;
let Xballspeed = 8;
let Yballspeed = 8;
let ray = ballDia / 2;

//Rect
let Xrect = 5;
let Yrect = 150;
let Crect = 10;
let Hrect = 90;

//Enemy
let Xrectenemy = 585;
let Yrectenemy = 150;
let Yenemyspeed; 


//Collide
let Hit = false;

//Score
let Myscore = 0;
let Enemyscore = 0;
  
function setup() {
  createCanvas(600, 400);
}
function draw() {
  background("rgb(1,1,1)");
  VisualBall();
  VisualRect(Xrect, Yrect);
  VisualRect(Xrectenemy, Yrectenemy);
  MovimentBall(); 
  Xball += Xballspeed;
  Yball += Yballspeed;
  MovimentRect();
  MovimentRectEnemy();
  CollisionFix();
  CollisionRect(Xrect,Yrect);
  CollisionRect(Xrectenemy,Yrectenemy);
  ScoreBoard();
  Score();
  BallBug();
}

function VisualBall(){
  fill("rgb(100,100,100)");
  circle(Xball, Yball, ballDia);
}
function MovimentBall(){
    if (Xball + ray > width || Xball - ray < 0) {
    Xballspeed *= -1;
  }
  if (Yball + ray > height || Yball - ray < 0) {
    Yballspeed *= -1;
  }
 }
function VisualRect(x,y){
  fill("rgb(100,100,100)");
  rect(x, y, Crect, Hrect);
}
function MovimentRect(){
    if (keyIsDown(UP_ARROW)){
    Yrect-=10}
    if (keyIsDown(DOWN_ARROW)){
      Yrect+=10}

  if (Xball - ray < Xrect + Crect &&
      Yball - ray < Yrect + Hrect &&
      Yball + ray > Yrect){
    Xballspeed *=-1;
  }
}
function CollisionFix() {
  if (Xball - ray < Xrect + Crect && Yball - ray < Yrect + Hrect && Yball + ray > Yrect) {
    Xballspeed *= -1;
  }
}

function CollisionRect(x,y){
  Hit = collideRectCircle(x, y, Crect, Hrect, Xball, Yball, ray);
  if(Hit){
   Xballspeed *=-1;
  }
}
function MovimentRectEnemy(){
  if (keyIsDown(87)){
    Yrectenemy-=10} 
    if (keyIsDown(83)){
      Yrectenemy+=10}  
}
function ScoreBoard(){
  stroke("rgb(255,255,255)")
  textAlign(CENTER);
  textSize(13);
  fill("rgb(100,100,100)");
  text(Myscore, 150, 25);
  text(Enemyscore, 450, 25);
}
function Score(){
  if(Xball < 15){
    Enemyscore += 1;
  }
  if(Xball > 585){
    Myscore += 1;
  }
}
function BallBug(){
    if (Xball - ray < 0){
    Xball = 12
    }
}
